from view.gui import GUI

gui = GUI()
gui.create()
gui.start()