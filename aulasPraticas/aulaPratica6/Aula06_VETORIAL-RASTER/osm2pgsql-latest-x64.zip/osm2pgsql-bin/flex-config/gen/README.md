# Flex Output Configuration for Generalization

These are config file examples for use with the generalization support.

GENERALIZATION SUPPORT IS EXPERIMENTAL. EVERYTHING IN THIS DIRECTORY MIGHT
CHANGE WITHOUT NOTICE.

See the [Flex Output](https://osm2pgsql.org/doc/manual.html#the-flex-output)
and [Generalization](https://osm2pgsql.org/doc/manual.html#generalization)
chapters in the manual for all the details.

## Public Domain

All the example config files in this directory are released into the Public
Domain. You may use them in any way you like.

