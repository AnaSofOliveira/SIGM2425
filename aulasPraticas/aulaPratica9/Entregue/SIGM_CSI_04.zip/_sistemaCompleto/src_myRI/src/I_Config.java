/**
 * @author Paulo Trigo Silva (PTS)
 */


public interface I_Config
{
   final public static String _kDirectorioComOsIndices = "_osMeusIndices";
}
